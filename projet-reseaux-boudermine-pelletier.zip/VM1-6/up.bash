cd ./VM1-6; vagrant up
