cd ./VM3-6; vagrant up
