cd ./VM2-6; vagrant up
