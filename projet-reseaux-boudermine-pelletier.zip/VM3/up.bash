cd ./VM3; vagrant up
