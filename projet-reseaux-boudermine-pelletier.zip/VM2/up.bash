cd ./VM2; vagrant up
