cd ./VM1; vagrant up
